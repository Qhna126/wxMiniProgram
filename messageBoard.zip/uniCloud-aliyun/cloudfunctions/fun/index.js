const { promises } = require("dns");

let db = uniCloud.database({
	throwOnNotFound: false,
})
exports.main = async (event, context) => {
	const _ = db.command
	if (event.api === 'publish') {
		return await db.collection(`${event.groupName}`).add({
			content: event.content,
			avatarUrl: event.avatarUrl,
			nickName: event.nickName,
			date: event.date,
			public: true
		})
	}

	if (event.api === 'getMessages') {
			return await db.collection(`${event.groupName}`).get()
	}
	
	if (event.api === 'getGroups') {
		return await db.collection('group').get()
	}

	if (event.api === 'reply') {
		return await db.collection(`${event.groupName}`).where({
			_id: event._id
		}).update({
			replies: _.push([{
				r_nickName: event.nickName,
				r_content: event.content
			}, ])
		})
	}

	if (event.api === 'createGroup') {
		let num = await db.collection('group').count() 
		let groupId = parseInt(num.total) +1
		return await db.collection('group').add({
			groupId: groupId,
			groupName: event.groupName,
			leader: event.leader,
			tel: event.tel,
			info: event.info,
		})
	}
	//返回数据给客户端
	return ""
};
