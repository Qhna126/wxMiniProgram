let db = uniCloud.database({
	throwOnNotFound: false,
})
exports.main = async (event, context) => {
	const _ = db.command 
	if (event.api === 'publish') {
		return await db.collection('message').add({
			content: event.content,
			avatarUrl: event.avatarUrl,
			nickName: event.nickName,
			date: event.date,
			public: true
		})
	}
	
	if (event.api === 'getMessages') {
		return await db.collection('message').get()
	}
	
	if (event.api === 'reply') {
		return await db.collection('message').where({
			_id: event._id
		}).update({
			replies: _.push([
				{
					r_nickName: event.nickName,
					r_content: event.content
				},
			])
		})
	}

	if (event.api === 'createGroup') {
		
	}
	//返回数据给客户端
	return ""
};
