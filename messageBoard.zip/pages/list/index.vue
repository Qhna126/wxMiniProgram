<template>
	<view>
		<view>
			<view class="cover">
				<image src="/images/团队-17.png" class="logo" />
			</view>
		</view>

		<view class="title">嗨~欢迎来到qiu!</view>
		<view class="desc">这里是qiu的分组小程序V1 版本</view>

		<view wx:if="{{!groupId}}" class="desc">请在下方选择你的分组倾向</view>
		<view class="choose">
			<navigator class="join" url="/pages/form/index">创建小组</navigator>
			<navigator class="join" url="/pages/list/index">加入小组</navigator>
			<navigator class="join" url="/pages/comment/index">
				留言板
			</navigator>
		</view>
		<view class="hr"></view>
		<navigator url="/pages/webview/index">
			<view class="text">更多细节可以点击这里前往github仓库查看：</view>
			<view class="text link">https://github.com/Qhna126/wxMiniProgram</view>
		</navigator>
		<view class="cover"></view>
	</view>
</template>

<style scoped>
	.cover {
		background-color: gray(84, 84, 175);
		text-align: center;
		padding: 80rpx;
	}

	.logo {
		width: 210px;
		height: 150px;
	}

	.title {
		font-weight: 500;
		color: #000000;
		font-size: 44rpx;
		margin: 50rpx 32rpx;
	}

	.desc {
		font-size: 28rpx;
		font-weight: 400;
		color: #888888;
		margin: 32rpx;
	}

	.text {
		margin: 32rpx;
		color: #333;
		overflow-wrap: break-word;
		line-height: 1.7;
	}

	.hr {
		margin: 32rpx;
		border-top: 1px solid #999;
	}

	.link {
		color: #216cd3;
		text-decoration: none;
		border-bottom: 1px dashed;
	}

	.red {
		color: rgb(253, 91, 91);
	}

	.b {
		font-weight: bold;
	}

	.choose {
		margin: 80rpx auto;
	}

	.join {
		width: 400rpx;
		height: 100rpx;
		background-color: #07c160;
		margin: 50rpx auto;
		text-align: center;
		line-height: 100rpx;
		color: #fff;
		font-weight: bold;
		border-radius: 12rpx;
	}
</style>
