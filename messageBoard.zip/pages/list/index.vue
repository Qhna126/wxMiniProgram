<template>
	<view class="page">
		<view v-for="(group, index) in groupList" :key="group.groupId">
			<navigator :url="'/pages/comment/index?groupName='+group.groupName" class="card">
				<view class="txt">
					<view class="title">组号：</view>
					<view class="info">{{group.groupId}}</view>
				</view>
				<view class="txt">
					<view class="title">记录名：</view>
					<view class="info">{{group.groupName}}</view>
				</view>
				<view class="txt">
					<view class="title">负责人：</view>
					<view class="info">{{group.leader}}</view>
				</view>
				<view class="txt">
					<view class="title">简介：</view>
					<view class="info">{{group.info}}</view>
				</view>

			</navigator>
		</view>
	</view>
	<view class="bottom">
		<view class="toast">已无更多小组</view>
		<navigator open-type="redirect" url="/pages/form/index" class="join">点这里去自行创建小组</navigator>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				groupList: []
			}
		},
		onLoad() {
			uniCloud.callFunction({
					name: 'fun',
					data: {
						api: 'getGroups',
					},
				})
				.then((res) => {
					this.groupList = res.result.data
				})
		}
	}
</script>

<style scoped>
	.page {
		background-color: #eeeeee;
		padding: 20rpx 0;
		min-height: 100vh;
	}

	.card {
		margin: 40rpx;
		background-color: #fff;
		border-radius: 12rpx;
		box-shadow: rgb(0 0 0 / 20%) 0px 2px 1px -1px,
			rgb(0 0 0 / 14%) 0px 1px 1px 0px, rgb(0 0 0 / 12%) 0px 1px 3px 0px;
		padding: 20rpx;
	}

	.txt {
		margin: 16rpx 0;
		display: flex;
	}

	.title {
		color: #666;
		width: 200rpx;
		flex: 1;
	}

	.info {
		color: #333;
		flex: 3;
	}

	.toast {
		text-align: center;
		font-size: 40rpx;
		color: #555;
	}

	.join {
		width: 400rpx;
		height: 100rpx;
		background-color: #1296db;
		margin: 50rpx auto 500px;
		text-align: center;
		line-height: 100rpx;
		color: #fff;
		font-weight: 600;
		border-radius: 12rpx;
	}

</style>
