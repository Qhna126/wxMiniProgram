<template>
	<view class="body_1">
		<view class="body">
			<form @submit="formSubmit" @reset="formReset">

				<view class="section">
					<view class="title">小组昵称：</view>
					<input type="groupName" class="input" name="groupName" placeholder="昵称" />
				</view>
				<view class="section">
					<view class="title">创建人：</view>
					<input type="leader" class="input" name="leader" placeholder="昵称" />
				</view>
				<view class="section">
					<view class="title">可以添加到你的联系方式：</view>
					<input class="input" name="tel" placeholder="以防小组成员加不到你" />
				</view>
				<view class="section">
					<view class="title">小组介绍：</view>
					<textarea style="height:100rpx" class="input" name="info" placeholder="{{info}}" />
				</view>
				<view class="area">
					<button style="margin: 30rpx 0" form-type="submit" bind:>提交</button>
					<button style="margin: 30rpx 0" form-type="reset">重置</button>
				</view>
			</form>
		</view>
	</view>

</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {
			formSubmit: function(e) {
				console.log(e.detail.value);
				let formData = e.detail.value
				uniCloud.callFunction({
					name: 'fun',
					data:{
						api: 'createGroup',
						groupName: formData.groupName,
						leader: formData.leader,
						tel: formData.tel,
						info: formData.info,
					}
				})
			},
			formReset: function(e) {
				console.log('清空数据')
			}
		}
	}
</script>

<style scoped>
	.body_1 {
		background-color: #eeeeee;
		/* margin: 0 40rpx; */
	}

	.body {
		margin: 0 20rpx 20rpx 20rpx;
	}

	.section {
		margin: 0 0 80rpx;
		background-color: #eeeeee;
	}

	.title {
		font-size: 36rpx;
	}

	.input {
		margin: 30rpx 0;
		border-bottom: 1px solid #666;
		padding: 20rpx 0;
		width: 100%;
	}

	.mg {
		margin: 30rpx 0;
	}

	.area {
		margin: 100rpx auto;
		display: flex;
		justify-content: center;
		flex-direction: column;
		align-items: center;
	}

	.area button:first-child {
		background-color: #1296db;
	}
</style>
