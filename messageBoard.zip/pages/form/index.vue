<template>
	<view class="body_1">
		<view class="body">
			<form bindsubmit="submit">
				<view class="section">
					<view class="title">小组昵称：</view>
					<input type="nickname" class="input" name="nickname" placeholder="昵称" />
				</view>
				<view class="section">
					<view class="title">性别：</view>
					<radio-group class="mg" name="gender">
						<label>
							<radio value="nan" />
							男
						</label>
						<label>
							<radio value="nv" />
							女
						</label>
					</radio-group>
				</view>
				<view class="section">
					<view class="title">年龄：</view>
					
					<picker bindchange="dateChange" fields="year" value="{{date}}" mode="date" class="input"
						name="date">
						<view class="picker">出生年: {{date}}</view>
					</picker>
				</view>
				<view class="section">
					<view class="title">地区：（可选）</view>
					<picker bindchange="regionChange" value="{{region}}" mode="region" level="province" class="input"
						name="region">
						<view class="picker">当前选择: {{region}}</view>
					</picker>
				</view>
				<view class="section">
					<view class="title">可以添加到你的联系方式：</view>
					<input class="input" name="code" placeholder="以防小组成员加不到你" />
				</view>
				<view class="section">
					<view class="title">你的基础情况：</view>
					<textarea style="height:100rpx" class="input" name="info" placeholder="{{info}}" />
				</view>
				<view class="area">
					<button style="margin: 30rpx 0"  formType="submit" bind:>提交</button>
					<button style="margin: 30rpx 0" formType="reset">重置</button>
				</view>
			</form>
		</view>
	</view>

 </template>









<script>
	
	
	
</script>

<style scoped>
	.body_1 {
		background-color: #eeeeee;
		/* margin: 0 40rpx; */
	}
	.body{
		margin:0 20rpx 20rpx 20rpx	;
	}

	.section {
		margin: 0 0 80rpx;
		background-color: #eeeeee;
	}

	.title {
		font-size: 36rpx;
	}

	.input {
		margin: 30rpx 0;
		border-bottom: 1px solid #666;
		padding: 20rpx 0;
		width: 100%;
	}

	.mg {
		margin: 30rpx 0;
	}

	.area {
		margin: 100rpx auto;
		display: flex;
		justify-content: center;
		flex-direction: column;
		align-items: center;
	}
	.area button:first-child{
			background-color: #1296db;
		}
</style>
