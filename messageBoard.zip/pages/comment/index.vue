<template>
	<view>
		<view class="top-user">
			欢迎{{this.userList.nickName}}
			<view class="">
				<image :src="this.userList.avatarUrl" mode="aspectFill"></image>
			</view>
		</view>
		<!-- 留言框 -->
		<view class="comment" v-for="(res, index) in list" :key="res.id">
			<view class="left">
				<image :src="res.avatarUrl" mode="aspectFill"></image>
			</view>
			<view class="right">
				<view class="top">
					<view class="name">{{ res.nickName}}</view>
					<view class="like">
						<view class="">
							<uni-icons type="heart" size="12"></uni-icons>
						</view>
						<view class="num">{{likeNum}}</view>
					</view>
				</view>
				<view class="content">{{ res.content }}</view>
				<!-- 回复框 -->
				<view class="reply-box">
					<!-- <view class="item" v-for="(item, index) in res.replyList" :key="item.index"> -->
					<view class="" v-if="res.replies">
						<view class="item" v-for="(item, index) in res.replies" :key="item.index">
							<view>
								<view class="username">{{item.r_nickName}}</view>
								<view class="text">{{item.r_content}}</view>
							</view>
						</view>
					</view>
					<view class="all-reply" v-if="res.replies">
						共{{res.replies.length}}条回复
						<u-icon class="more" name="arrow-right" :size="26"></u-icon>
					</view>
				</view>

				<view class="bottom">
					{{ res.date }}
					<view class="reply" @click="openReplyBox(res._id)">回复</view>
				</view>
			</view>
		</view>
	</view>
	<!-- 评论回复弹出层 -->
	<uni-popup ref="popup1" type="bottom" background-color="#fff">
		<view class="comment-box">
			<textarea name="" id="" cols="30" rows="10" class="input" cursor-spacing="100" v-model="content"
				placeholder="记录你想说的话吧..."></textarea>
			<button class="button-publish" style="background-color: #1296db;" @click="publish()">记录</button>
		</view>
	</uni-popup>
	<uni-popup ref="popup2" type="bottom" background-color="#fff">
		<view class="comment-box">
			<textarea name="" id="" cols="30" rows="10" class="input" cursor-spacing="100" v-model="content"
				placeholder="..."></textarea>
			<button class="button-publish" style="background-color: #1296db;" @click="reply()" size="mini">回复</button>
		</view>
	</uni-popup>
	<!-- 发表评论按钮 -->
	<view class="" @click="openCommentBox()">
		<uni-fab horizontal="right" vertical="bottom" pattern="buttonColor: #1296db" popMenu="flase"></uni-fab>
	</view>

</template>

<script>
	import {
		formatDate
	} from "@/date.js";

	export default {
		data() {
			return {
				likeNum: 0,
				commentList: [],
				content: '',
				list: [],
				userList: {},
				replyId: '',
				propsGroupName: '',
			};
		},

		onLoad: function(option) {
			this.propsGroupName = option.groupName;
			let _this = this;
			//进入该页面时，获取留言板数据
			console.log(option.groupName);
			uniCloud.callFunction({
				name: 'fun',
				data: {
					api: "getMessages",
					groupName: this.propsGroupName,
				},
			}).then((res) => {
					this.list = res.result.data
					console.log(res);
					console.log("chengogngdiaoyong");
				},
				rej => {
					console.log("shibaile");
				});
		//清理缓存
		// uni.clearStorage({
		// 	success: res => {

		// 	},
		// 	fail: rej => {
		// 		console.log("清理失败");
		// 	}
		// })
		//获取用户信息
		uni.getStorage({
			key: "userProfile",
			success: res => {
				console.log("成功获取本地缓存");
				_this.userList.nickName = res.data.nickName;
				_this.userList.avatarUrl = res.data.avatar;
				console.log(_this.userList.nickName);
			},
			fail: reject => {
				console.log("未找到本地缓存");
				//调用showModal告知用户：正在获取头像、昵称
				uni.showModal({
					title: '提示',
					content: '小程序需要获取用户头像和昵称，仅用于展示使用',
					showCancel: false,
					success(res) {
						console.log("正在申请获取到用户profile");
						//调用接口getUserProfile获取用户信息
						if (res.confirm) {
							console.log('用户点击确定')
							uni.getUserProfile({
								desc: "仅用于展示头像和昵称",
								success: res => {
									// res.userInfo.avatarUrl.replace('132', '46')
									_this.userList.nickName = res.userInfo
										.nickName;
									_this.userList.avatarUrl = res.userInfo
										.avatarUrl;
									uni.setStorage({
										key: 'userProfile',
										data: {
											nickName: res.userInfo
												.nickName,
											avatar: res.userInfo.avatarUrl
										},
										success: res => {
											console.log("%%%%%%");
										}
									})
								},
								fail: rej => {
									console.log("用户拒绝");
									uni.showModal({
										title: '提示',
										content: '将匿名记录',
										showCancel: false,
									})
								}
							})
						} else if (res.cancel) {
							console.log('用户点击取消')
						}
					}
				});

			}
		})
	},

	methods: {
		isLike() {
			this.likeNum = this.likeNum + 1
		},

		openCommentBox() {
			// 通过组件定义的ref调用uni-popup方法 ,如果传入参数 ，type 属性将失效 ，仅支持 ['top','left','bottom','right','center']
			this.$refs.popup1.open()
		},

		openReplyBox(_id) {
			// 通过组件定义的ref调用uni-popup方法 ,如果传入参数 ，type 属性将失效 ，仅支持 ['top','left','bottom','right','center']
			this.$refs.popup2.open()
			// uni.$emit("send_id", _id);
			this.replyId = _id;
		},

		reply() {
			uniCloud.callFunction({
				name: 'fun',
				data: {
					api: 'reply',
					groupName: this.propsGroupName,
					_id: this.replyId,
					content: this.content,
					nickName: this.userList.nickName,
					data: formatDate('yyyy-MM-dd hh:mm:ss', Date())
				}
			}).then(res => {
				this.content = ''
				uni.showToast({
					title: '回复成功',
					icon: 'success'
				})
			})
		},

		publish() {
			uniCloud.callFunction({
				name: 'fun',
				data: {
					api: 'publish',
					groupName: this.propsGroupName,
					content: this.content,
					avatarUrl: this.userList.avatarUrl,
					nickName: this.userList.nickName,
					date: formatDate('yyyy-MM-dd hh:mm:ss', Date()),
				}
			}).then(res => {

				this.list.push({
					_id: res.result.id,
					content: this.content,
					avatarUrl: this.userList.avatarUrl,
					nickName: this.userList.nickName,
					date: formatDate('yyyy-MM-dd hh:mm:ss', Date())
				})
				this.content = '';
				uni.showToast({
					title: '发布成功',
					icon: 'success'
				})
			})
		}
	}
	};
</script>

<style lang="scss" scoped>
	.top-user {
		background-color: #e6e6e6;
		border-bottom: solid 1px #999999;

		image {
			margin-top: 20rpx;
			width: 64rpx;
			height: 64rpx;
			border-radius: 50%;
			background-color: #f2f2f2;
		}
	}

	.comment-box {
		display: flex;
		// flex-direction: column-reverse;
		align-items: flex-start;
		margin: 40rpx;

		.input {
			font-size: 13px;
			border-radius: 10px;
			height: 80px;
			background-color: lightgray;
		}

		.button-publish {
			height: 2rem;
			font-size: 1rem;
			line-height: 1rem;
			text-align: center;
		}
	}

	.comment {
		display: flex;
		padding: 30rpx;

		.left {
			image {
				width: 64rpx;
				height: 64rpx;
				border-radius: 50%;
				background-color: #f2f2f2;
			}
		}

		.right {
			flex: 1;
			padding-left: 20rpx;
			font-size: 30rpx;

			.top {
				display: flex;
				justify-content: space-between;
				align-items: center;
				margin-bottom: 10rpx;

				.name {
					color: #5677fc;
				}

				.like {
					display: flex;
					align-items: center;
					color: #9a9a9a;
					font-size: 26rpx;

					.num {
						margin-right: 4rpx;
						color: #9a9a9a;
					}
				}

				.highlight {
					color: #5677fc;

					.num {
						color: #5677fc;
					}
				}
			}

			.content {
				margin-bottom: 10rpx;
				// margin: 0px;
			}

			.reply-box {
				background-color: rgb(242, 242, 242);
				border-radius: 12rpx;

				.item {
					padding: 20rpx;
					border-bottom: solid 2rpx lightgray;

					.username {
						font-size: 24rpx;
						color: #999999;
					}
				}

				.all-reply {
					padding: 20rpx;
					display: flex;
					color: #5677fc;
					align-items: center;

					.more {
						margin-left: 6rpx;
					}
				}
			}

			.bottom {
				margin-top: 20rpx;
				display: flex;
				font-size: 20rpx;
				color: #9a9a9a;

				.reply {
					font-size: 24rpx;
					color: #5677fc;
					margin-left: 10rpx;
				}
			}
		}
	}
</style>
